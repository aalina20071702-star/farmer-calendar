# utils/database.py
import pandas as pd

import sqlite3

def get_connection():
    """Возвращает соединение с SQLite в памяти"""
    conn = sqlite3.connect(':memory:')
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Создаёт таблицы и наполняет их данными из CSV"""
    conn = get_connection()
    c = conn.cursor()

    # Таблица событий
    c.execute('''
        CREATE TABLE IF NOT EXISTS events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_name TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            event_type TEXT NOT NULL,
            category_tags TEXT,
            target_audience TEXT,
            base_post_text TEXT
        )
    ''')

    # Таблица товаров (ровно по структуре твоей БД + наши поля)
    c.execute('''
        CREATE TABLE IF NOT EXISTS products (
            product_id TEXT PRIMARY KEY,
            organization_id TEXT,
            shop_name TEXT,
            farmer_description TEXT,
            region TEXT,
            category TEXT,
            name_product TEXT,
            product_description TEXT,
            url_product TEXT,
            url_farmer TEXT
        )
    ''')

    conn.commit()
    conn.close()
    print("✅ База данных инициализирована")


def load_events_from_csv(csv_path="data/events.csv"):
    """Загружает события из CSV в таблицу events"""
    conn = get_connection()
    try:
        df = pd.read_csv(csv_path)
    except:
        # В Cloud Functions путь другой
        df = pd.read_csv('/function/code/data/events.csv')
    df.to_sql('events', conn, if_exists='replace', index=False)
    conn.commit()
    conn.close()
    print(f"✅ Загружено {len(df)} событий")


def load_products_from_csv(csv_path="data/farmer_sku.csv"):
    conn = get_connection()
    try:
        df = pd.read_csv(csv_path)
    except:
        # В Cloud Functions путь другой
        df = pd.read_csv('/function/code/data/farmer_sku.csv')
    df.to_sql('products', conn, if_exists='replace', index=False)
    conn.commit()
    conn.close()
    print(f"✅ Загружено {len(df)} товаров")


def get_all_events():
    """Возвращает все события в виде списка словарей"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM events ORDER BY start_date")
    events = [dict(row) for row in c.fetchall()]
    conn.close()
    return events


def get_products_by_category(category):
    """Возвращает товары по категории"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE category = ?", (category,))
    products = [dict(row) for row in c.fetchall()]
    conn.close()
    return products


def get_all_products():
    """Возвращает все товары"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM products")
    products = [dict(row) for row in c.fetchall()]
    conn.close()
    return products


def get_products_for_event(event):
    """Находит товары, подходящие под событие по тегам (гибкое сравнение)"""
    tags_raw = event['category_tags']  # "мёд, чай, варенье"

    # Разбиваем, чистим пробелы, приводим к нижнему регистру
    tags = [t.strip().lower() for t in tags_raw.split(',')]

    # Загружаем все товары
    all_products = get_all_products()

    matched = []
    for p in all_products:
        product_category = p['category'].lower().strip()
        product_name = p['name_product'].lower().strip()
        product_desc = p['product_description'].lower().strip()

        # Проверяем совпадение хотя бы одного тега
        for tag in tags:
            if (tag in product_category or
                    tag in product_name or
                    tag in product_desc):
                matched.append(p)
                break  # Чтобы не добавлять один товар дважды

    return matched